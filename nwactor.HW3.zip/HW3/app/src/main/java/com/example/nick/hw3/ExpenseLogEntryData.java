package com.example.nick.hw3;

import java.util.Date;

/**
 * Created by Nick on 11/17/2016.
 */

public class ExpenseLogEntryData {
    private String description;
    private String notes;
    private String timeDate;

    public ExpenseLogEntryData(String description, String notes) {
        this.description = description;
        this.notes = notes;
        Date date = new Date();
        this.timeDate = date.toString();
    }

    //second constructor for loading from SQL database
    public ExpenseLogEntryData(String description, String notes, String timeDate) {
        this.description = description;
        this.notes = notes;
        this.timeDate = timeDate;
    }

    public String getDescription() {
        return this.description;
    }

    public String getNotes() {
        return this.notes;
    }

    public String getTimeDate() {
        return this.timeDate;
    }

    public void setDescription(String newDescription) {
        this.description = newDescription;
    }

    public void setNotes(String newNotes) {
        this.notes = newNotes;
    }

    public void setTimeDate(String newTimeDate) {
        this.timeDate = newTimeDate;
    }

}
