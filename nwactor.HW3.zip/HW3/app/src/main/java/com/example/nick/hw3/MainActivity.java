package com.example.nick.hw3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.RelativeLayout;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    static ExpenseTrackerAdapter adapter;
    private ListView lView;
    private DatabaseHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //create and own the ListView
        ListView list = (ListView) findViewById(R.id.list);
        this.lView = list;

        this.db = new DatabaseHandler(this);
        /*NOTE -- I start the app with three example expenses like in HW2, so if you delete all of the
         * expenses and then close the app these default ones will come back. However, that could easily
          * be changed by deleting this if statement. */
        if(db.getNumberOfEntries() == 0) {
            db.addEntry(new ExpenseLogEntryData("Car", "This was a really nice car"));
            db.addEntry(new ExpenseLogEntryData("Horse", "Whinny whinny neigh neigh"));
            db.addEntry(new ExpenseLogEntryData("Bike", "Who needs a motor when you've got pedals?"));
        }

        //create and own the ExpenseTrackerAdapter
        adapter = new ExpenseTrackerAdapter(db);

        //set the ListView's adapter
        list.setAdapter(adapter);
    }

    public void addExpense(View view) {
        Intent intent = new Intent(this, EnterData.class);
        startActivity(intent);
    }

    public void deleteEntry(View button) {
        //get the button's parent - ie the whole list entry
        View entry = (View) button.getParent();
        int position = this.lView.getPositionForView(entry);
        ExpenseLogEntryData entryData = this.adapter.getList().get(position);

        //remove the item visually
        this.lView.removeViewInLayout(entry);

        //remove the item from the internal ArrayList

        this.adapter.getList().remove(position);

        //remove the item from the database
        this.db.deleteEntry(entryData);

        //Could also make it so each view slides up after the one above it is deleted...
    }

}
