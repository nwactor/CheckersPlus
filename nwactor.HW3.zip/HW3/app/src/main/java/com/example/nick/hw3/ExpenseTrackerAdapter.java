package com.example.nick.hw3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Nick on 11/17/2016.
 */

public class ExpenseTrackerAdapter extends BaseAdapter {
    private ArrayList<ExpenseLogEntryData> list;
    private DatabaseHandler db;

    public ExpenseTrackerAdapter(DatabaseHandler db) {
        this.db = db;
        this.list = new ArrayList<ExpenseLogEntryData>();

        //add the items from the database to the list so it will be displayed on the screen
        for(ExpenseLogEntryData entry : db.getAllEntries()) {
            list.add(entry);
        }
    }

    //add an expense to the list
    public void add(ExpenseLogEntryData data) {
        this.list.add(data);
        this.db.addEntry(data);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        if(list.get(position) != null) {
            return list.get(position);
        } else {
            return null;
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Context context = parent.getContext();
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View view = inflater.inflate(R.layout.list_layout, parent, false);

        TextView rowDescription = (TextView) view.findViewById(R.id.description);
        TextView rowNotes = (TextView) view.findViewById(R.id.notes);
        TextView rowDates = (TextView) view.findViewById(R.id.date);

        ExpenseLogEntryData expenseEntry = this.list.get(position);

        rowDescription.setText(expenseEntry.getDescription());
        rowNotes.setText(expenseEntry.getNotes());
        rowDates.setText(expenseEntry.getTimeDate());

        return view;
    }

    public ArrayList<ExpenseLogEntryData> getList() {
        return this.list;
    }

}
