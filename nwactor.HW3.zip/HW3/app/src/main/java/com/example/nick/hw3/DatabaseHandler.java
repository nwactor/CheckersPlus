package com.example.nick.hw3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nick on 11/17/2016.
 */

public class DatabaseHandler extends SQLiteOpenHelper {
    private static final String databaseName = "listManager";
    private static final String tableName = "expenses";

    private static final String description = "description";
    private static final String notes = "notes";
    private static final String time = "time";


    public DatabaseHandler(Context context) {
        super(context, databaseName, null, 1);
    }

    public void onCreate(SQLiteDatabase db) {
        String CREATE_EXPENSES_TABLE = "CREATE TABLE " + tableName + " (description TEXT, notes TEXT, time TEXT)";
        db.execSQL(CREATE_EXPENSES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + tableName);

        onCreate(db);
    }

    //add an entry to the database
    public void addEntry(ExpenseLogEntryData entry){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(description, entry.getDescription());
        values.put(notes, entry.getNotes());
        values.put(time, entry.getTimeDate());

        db.insert(tableName, null, values);
        db.close();
    }

    //get all the entries in the database
    public List<ExpenseLogEntryData> getAllEntries() {
        List<ExpenseLogEntryData> entryList = new ArrayList<ExpenseLogEntryData>();
        String selectQuery = "SELECT  * FROM " + tableName;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                ExpenseLogEntryData entry = new ExpenseLogEntryData(cursor.getString(0), cursor.getString(1), cursor.getString(2));
                // Adding contact to list
                entryList.add(entry);
            } while (cursor.moveToNext());
        }

        return entryList;
    }

    //For some reason this doesn't work
    /*
    public ExpenseLogEntryData getEntry(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = { description, notes, time };

        Cursor cursor = db.query(tableName, columns, description + " = ?", new String[] {String.valueOf(id)},
                null, null, null, null);

        ExpenseLogEntryData entry = null;

        try {
            if(cursor != null && cursor.moveToFirst()) {
                entry = new ExpenseLogEntryData(cursor.getString(0), cursor.getString(1), cursor.getString(2));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cursor.close();
            db.close();
        }

        return entry;
    }
    */

    //delete entry from database
    public void deleteEntry(ExpenseLogEntryData entry) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(tableName, "description" + " = ?",
                new String[] { String.valueOf(entry.getDescription()) });
        db.close();
    }

    //get the number of rows in the database
    public int getNumberOfEntries() {
        String countQuery = "SELECT  * FROM " + tableName;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        //cursor.close();

        return cursor.getCount();
    }

}
