package com.example.nick.hw3;

import android.content.ContentValues;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class EnterData extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_data);
    }

    //only save & return if the user has input both data AND description; otherwise save does nothing
    public void save(View view) {
        EditText data = (EditText) findViewById(R.id.enterData);
        EditText description = (EditText) findViewById(R.id.enterDescription);
        if(data.getText().length() != 0 && description.getText().length() != 0) {
            ExpenseLogEntryData newEntry = new ExpenseLogEntryData(data.getText().toString(), description.getText().toString());
            MainActivity.adapter.add(newEntry);

            //add to content provider
            ContentValues mNewValues = new ContentValues();

            finish();
        }
    }

    //cancel just returns to the main activity
    public void cancel(View view) {
        finish();
    }
}
